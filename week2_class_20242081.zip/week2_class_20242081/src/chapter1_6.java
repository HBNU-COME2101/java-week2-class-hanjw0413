import java.util.Scanner;

public class chapter1_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);

        System.out.print("(x1, y1), (x2, y2)의 좌표 입력 >> ");
        int x1 = scanner.nextInt();
        int y1 = scanner.nextInt();
        int x2 = scanner.nextInt();
        int y2 = scanner.nextInt();

        int rectX1 = 10, rectY1 = 10, rectX2 = 200, rectY2 = 300;

        if ((x1 >= rectX1 && x1 <= rectX2 && y1 >= rectY1 && y1 <= rectY2) &&
            (x2 >= rectX1 && x2 <= rectX2 && y2 >= rectY1 && y2 <= rectY2)) {
            System.out.println("(" + x1 + "," + y1 + "), (" + x2 + "," + y2 + ") 사각형은 (" +
                               rectX1 + "," + rectY1 + ") (" + rectX2 + "," + rectY2 + ") 사각형에 포함된다.");
        } else {
            System.out.println("(" + x1 + "," + y1 + "), (" + x2 + "," + y2 + ") 사각형은 (" +
                               rectX1 + "," + rectY1 + ") (" + rectX2 + "," + rectY2 + ") 사각형에 포함되지 않는다.");
        }

        scanner.close();

	}

}
