import java.util.Scanner;

public class chapter1_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        System.out.print("나이를 입력하세요>> ");
        int age = scanner.nextInt();

        if (age <= 0) {
            System.out.println("나이는 양수로만 입력하세요.");
            return;
        }

        int redCandles = age / 10;
        age %= 10;
        
        int blueCandles = age / 5;
        age %= 5;
        
        int yellowCandles = age;
        
        String result = "";
        
        if (redCandles > 0) {
            result += "빨간 초 " + redCandles + "개, ";
        }
        
        if (blueCandles > 0) {
            result += "파란 초 " + blueCandles + "개, ";
        }
        
        if (yellowCandles > 0) {
            result += "노란 초 " + yellowCandles + "개, ";
        }
        
        if (!result.isEmpty()) {
            result = result.substring(0, result.length() - 2);
        }

        int totalCandles = redCandles + blueCandles + yellowCandles;
        result += ". 총 " + totalCandles + "개가 필요합니다.";

        System.out.println(result);
        
        scanner.close();
	}
}
