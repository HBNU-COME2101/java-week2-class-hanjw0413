import java.util.Scanner;

public class chapter1_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("여행지 >> ");
        String destination = scanner.nextLine();

        System.out.print("인원수 >> ");
        int numPeople = scanner.nextInt();

        System.out.print("숙박일 >> ");
        int stayDays = scanner.nextInt();

        System.out.print("1인당 항공료 >> ");
        int airfarePerPerson = scanner.nextInt();

        System.out.print("1방 숙박비 >> ");
        int roomCostPerNight = scanner.nextInt();

        int totalAirfare = numPeople * airfarePerPerson;

        int numRooms = (numPeople + 1) / 2;

        int totalRoomCost = numRooms * roomCostPerNight * stayDays;

        int totalCost = totalAirfare + totalRoomCost;

        System.out.println(numPeople + "명의 " + destination + " " + stayDays + "박 " + (stayDays + 1) + "일 여행에는 " + numRooms + "개 방이 필요하며 경비는 " + totalCost + "원입니다.");

        scanner.close();
	}

}
