
public class chapter1_2 {
	public static void main(String[] args) {
		String studentID = "20242081";
		String name = "한정원";
		
		System.out.println("학번:"+ studentID);
		System.out.println("이름:"+ name);
	}
}
